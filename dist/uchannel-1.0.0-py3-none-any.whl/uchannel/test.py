if __name__ == '__main__':
    from pathlib import Path
    from uchannel.uchannel1 import UChannel1
    from uchannel.uchannel2 import UChannel2
    from uchannel.uchannel3 import UChannel3
    from uchannel.uchannel4 import UChannel4

    # Define directories and paths
    work_dir = r"C:\Testsektion\232_uchannel_test"

    # # uchannel1
    # geom_path = Path(work_dir) / 'uchannel1.step'
    #
    # # Instantiate the geometry
    # u1 = UChannel1(geom_path, x_1=100, x_2=105, y_l=50, y_r=50, z_l_1=33.3, z_l_2=33.3, z_r_1=33.3, z_r_2=33.3,
    #                offset_mp_1=(1, 1, 1), offset_mp_2=(1, 1, 1), r_l=(5, 5), r_r=(5, 5),
    #                beta_l_1=15, beta_l_2=15, beta_r_1=15, beta_r_2=15, y_sa=50, sa=True)
    #
    # # Check the feasibility
    # if u1.check_feasibility():
    #     # Create the geometry
    #     u1.gmsh_filleting = True
    #     u1.create_geometry(export=True, gui=True)

    # # uchannel2
    # geom_path = Path(work_dir) / 'uchannel2.step'
    #
    # # Instantiate the geometry
    # u2 = UChannel2(geom_path, x_m=250, x_l=75, x_r=75, ll=100, lr=100, z_m=50, z_l=33.3, z_r=33.33, y_m=52.5, y_l=56.25,
    #                y_r=56.25, y_sa=15, alpha_l=30, alpha_r=30, beta_l=15, beta_r=15, beta_m=15, r=0.0, sa=True,
    #                la=True, ra=True)
    #
    # # Check the feasibility
    # if u2.check_feasibility():
    #     # Create the geometry
    #     u2.gmsh_filleting = True
    #     u2.create_geometry(export=True, gui=True)

    # # uchannel3
    # geom_path = Path(work_dir) / 'uchannel3.step'
    #
    # # Instantiate the geometry
    # u3 = UChannel3(geom_path, x_b1=100, x_b2=10, x_ad=20, l_c1=14.29, l_c2=14.92, x_t=10, y_m=20, alpha=20, z_ad=0,
    #                z_b=10, z_t=6.7, beta_b=5, beta_c=15, beta_t=5, y_sa=5, r=0.0, ad=True, sa=True)
    #
    # # Check the feasibility
    # if u3.check_feasibility():
    #     # Create the geometry
    #     u3.gmsh_filleting = True
    #     u3.create_geometry(export=True, gui=True)
    #
    # # uchannel4
    # geom_path = Path(work_dir) / 'uchannel4.step'
    #
    # # Instantiate the geometry
    # u4 = UChannel4(geom_path, x_m=100, ll=25, lr=25, z_m=20, z_l=15, z_r=15, y_m=25, y_l=25, y_r=25, y_sa=12.5, r=0.0,
    #                sa=True, alpha_l=0, alpha_r=0, beta_m=5, beta_l=5, beta_r=5)
    #
    # # Check the feasibility
    # if u4.check_feasibility():
    #     # Create the geometry
    #     u4.gmsh_filleting = True
    #     u4.create_geometry(export=True, gui=True)

    import os
    import logging
    from functions import create_imagegrid
    from uchannel.sampler import Sampler
    logging.basicConfig(level=logging.INFO)

    # # Generate samples of UChannel1
    # set directories
    data_dir = Path(work_dir) / 'uchannel1_data'
    os.makedirs(data_dir, exist_ok=True)

    # instantiate Sampler
    u1_sampler = Sampler(UChannel1, gmsh_filleting=True, n_samples=10, data_dir=data_dir, limiting_parameter=400)

    # get the bounds for the remaining parameters for the given limiting parameter
    u1_sampler.get_bounds()

    # generate the samples
    u1_sampler.generate_samples(gen_image=True, parallel=False)

    # Create an Imagegrid of the generated samples
    path_imagegrid = Path(data_dir) / 'imagegrid.png'
    create_imagegrid(data_dir=data_dir, outpath=path_imagegrid)
